import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate


# Define the function to evaluate f(x, y)
def f(x, y, expression):
    return eval(expression)


# Picard's Iteration Method
def picards_method(f, x0, y0, h, max_iterations, expression, tolerance):
    x_values = [x0]
    y_values = [y0]

    # Starting iteration
    for iteration in range(max_iterations):
        y_next = y0 + h * f(x0, y0, expression)  # First-order approximation
        y_next_values = [y_next]  # Store the new y values

        # Iteratively improve the approximation using Picard's formula
        for i in range(1, iteration + 2):
            y_next = y0 + h * f(x0 + i * h, y_next_values[i - 1], expression)
            y_next_values.append(y_next)

        # Update the results
        y_current = y_next_values[-1]
        x_next = x0 + (iteration + 1) * h

        # Append the results to the lists
        x_values.append(x_next)
        y_values.append(y_current)

        # Check for convergence
        if abs(y_current - y_values[-2]) < tolerance:
            break

        # Update the initial condition for the next iteration
        y0 = y_current

    return x_values, y_values


# User inputs
expression = input("Enter the function f(x, y) in terms of x and y (e.g., x + y, x*y): ")
x0 = float(input("Enter the initial value of x (x0): "))
y0 = float(input("Enter the initial value of y (y0): "))
h = float(input("Enter the step size (h): "))
max_iterations = int(input("Enter the maximum number of iterations: "))
tolerance = float(input("Enter the tolerance for convergence: "))

# Calculate values using Picard's method
x_values, y_values = picards_method(f, x0, y0, h, max_iterations, expression, tolerance)

# Display results in a table
results = list(zip(range(len(x_values)), x_values, y_values))
table = tabulate(results, headers=["Step", "x", "y"], tablefmt="pretty")
print("\nResults Table:")
print(table)

# Plotting the results
plt.plot(x_values, y_values, label="Picard's Method Approximation", marker='o')
plt.xlabel("x")
plt.ylabel("y")
plt.title("Solution of ODE using Picard's Method")
plt.legend()
plt.grid(True)
plt.show()
