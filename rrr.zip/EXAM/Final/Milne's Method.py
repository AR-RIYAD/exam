import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate


# Define the user function dy/dx = f(x, y)
def f(x, y, expression):
    return eval(expression)


# Milne's Method
def milnes_method(f, x0, y0, h, x_end, expression):
    # Initial values for x and y
    x_values = [x0]
    y_values = [y0]

    # Initial steps using Runge-Kutta method to get four starting values
    for i in range(3):
        k1 = h * f(x0, y0, expression)
        k2 = h * f(x0 + h / 2, y0 + k1 / 2, expression)
        k3 = h * f(x0 + h / 2, y0 + k2 / 2, expression)
        k4 = h * f(x0 + h, y0 + k3, expression)

        y0 = y0 + (k1 + 2 * k2 + 2 * k3 + k4) / 6
        x0 = x0 + h

        x_values.append(x0)
        y_values.append(y0)

    # Milne's predictor-corrector steps
    while x0 < x_end:
        # Predictor
        y_predict = y_values[-4] + (4 * h / 3) * (2 * f(x_values[-3], y_values[-3], expression) -
                                                  f(x_values[-2], y_values[-2], expression) +
                                                  2 * f(x_values[-1], y_values[-1], expression))

        # Corrector
        y_correct = y_values[-2] + (h / 3) * (f(x_values[-2], y_values[-2], expression) +
                                              4 * f(x_values[-1], y_values[-1], expression) +
                                              f(x0 + h, y_predict, expression))

        # Update values
        x0 += h
        x_values.append(x0)
        y_values.append(y_correct)

    return x_values, y_values


# User inputs
expression = input("Enter the function f(x, y) in terms of x and y (e.g., x + y, x*y): ")
x0 = float(input("Enter the initial value of x (x0): "))
y0 = float(input("Enter the initial value of y (y0): "))
h = float(input("Enter the step size (h): "))
x_end = float(input("Enter the final value of x (x_end): "))

# Calculate values using Milne's method
x_values, y_values = milnes_method(f, x0, y0, h, x_end, expression)

# Display results in a table
results = list(zip(range(len(x_values)), x_values, y_values))
table = tabulate(results, headers=["Step", "x", "y"], tablefmt="pretty")
print("\nResults Table:")
print(table)

# Plotting the results
plt.plot(x_values, y_values, label="Milne's Method Approximation", marker='o')
plt.xlabel("x")
plt.ylabel("y")
plt.title("Solution of ODE using Milne's Method")
plt.legend()
plt.grid(True)
plt.show()
