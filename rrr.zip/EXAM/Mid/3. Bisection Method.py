# # def f(x):
# #     return 2*x**2 - 5*x + 3   # Function from the given equation
# f = lambda x: 2*x**2 - 5*x + 3
#
# x1, x2 = map(float, input("Enter the initial interval (x1 x2): ").split())
# # x1 = 0, 2         # The initial guesses
# # x2 = 1.3
#
#
# y1 = f(x1)
# y2 = f(x2)
#
# if y1*y2 > 0:       # Signs of y-values are not opposite
#     print("No roots exist within the given interval")
#     raise SystemExit
#
# if y1*y2 == 0:      # One or both initial guess is the root
#     if y1 == 0: print('The root: %0.5f' % x1)
#     if y2 == 0: print('The root: %0.5f' % x2)
#     raise SystemExit
#
#                     # Signs of y-values are opposite
# xh = x1
# while abs(x1-x2) >= 1.0E-6: # or abs(f(xh)) >= 1e-6:
#     xh = (x1 + x2) / 2      # Bisection equation
#     yh = f(xh)
#
#     if y1 * yh < 0:         # The root is in the 1st half
#         x2 = xh             # x1 and y1 remains same
#
#     elif y1 * yh > 0:       # The root is in the 2nd half
#         x1 = xh             # x2 remains same
#         y1 = f(x1)          # y1 changes as x1 does
#
#     else: break             # The root equals to xh
#
# print('The Root: %0.5f' % xh)

# rrr
# def bisection_method(func, a, b, tol=1e-5, max_iter=100):
#     """
#     Find a root of a function in the interval [a, b] using the bisection method.
#
#     Parameters:
#     func (function): The function for which we are trying to find a root.
#     a (float): The start of the interval.
#     b (float): The end of the interval.
#     tol (float): The tolerance level for convergence.
#     max_iter (int): The maximum number of iterations.
#
#     Returns:
#     float: The root of the function within the specified tolerance.
#     None: If the root could not be found within the maximum number of iterations.
#     """
#     if func(a) * func(b) >= 0:
#         print("Bisection method fails. The function should have opposite signs at a and b.")
#         return None
#
#     for i in range(max_iter):
#         # Midpoint
#         midpoint = (a + b) / 2.0
#         # Check if midpoint is the root
#         if abs(func(midpoint)) < tol:
#             print(f"Root found at x = {midpoint} after {i+1} iterations")
#             return midpoint
#         # Decide the side to repeat the bisection
#         elif func(a) * func(midpoint) < 0:
#             b = midpoint
#         else:
#             a = midpoint
#
#     print("Maximum iterations reached. Solution may not have converged.")
#     return midpoint
#
# # Example usage:
# if __name__ == "__main__":
#     # Define a test function
#     def test_function(x):
#         return x**3 - x - 2
#
#     # Find root in the interval [1, 2]
#     root = bisection_method(test_function, 1, 2)
#     if root is not None:
#         print(f"Root: {root}")

# rrr
# def bisection_method(func, a, b, tol=1e-5, max_iter=100):
#     """
#     Find a root of a function in the interval [a, b] using the bisection method.
#
#     Parameters:
#     func (function): The function for which we are trying to find a root.
#     a (float): The start of the interval.
#     b (float): The end of the interval.
#     tol (float): The tolerance level for convergence.
#     max_iter (int): The maximum number of iterations.
#
#     Returns:
#     float: The root of the function within the specified tolerance.
#     None: If the root could not be found within the maximum number of iterations.
#     """
#     if func(a) * func(b) >= 0:
#         print("Bisection method fails. The function should have opposite signs at a and b.")
#         return None
#
#     for i in range(max_iter):
#         # Midpoint
#         midpoint = (a + b) / 2.0
#         # Check if midpoint is the root
#         if abs(func(midpoint)) < tol:
#             print(f"Root found at x = {midpoint} after {i+1} iterations")
#             return midpoint
#         # Decide the side to repeat the bisection
#         elif func(a) * func(midpoint) < 0:
#             b = midpoint
#         else:
#             a = midpoint
#
#     print("Maximum iterations reached. Solution may not have converged.")
#     return midpoint
#
# # Function to evaluate user-defined expression
# def user_function(x, expression):
#     return eval(expression)
#
# # Main code
# if __name__ == "__main__":
#     # Get the function from the user
#     expression = input("Enter the function in terms of x (e.g., x**3 - x - 2): ")
#
#     # Get the interval endpoints
#     a = float(input("Enter the start of the interval (a): "))
#     b = float(input("Enter the end of the interval (b): "))
#
#     # Get tolerance and maximum iterations
#     tol = float(input("Enter the tolerance (e.g., 1e-5): "))
#     max_iter = int(input("Enter the maximum number of iterations: "))
#
#     # Define the function to pass to the bisection method
#     func = lambda x: user_function(x, expression)
#
#     # Call the bisection method with user inputs
#     root = bisection_method(func, a, b, tol, max_iter)
#     if root is not None:
#         print(f"Root: {root}")
'''
# question1
# import numpy as np
# import matplotlib.pyplot as plt
# import pandas as pd
#
# # Constants
# g = 9.81  # acceleration due to gravity (m/s^2)
# m = 68.1  # mass of the parachutist (kg)
# v = 40.0  # target velocity (m/s)
# t = 10.0  # time (s)
#
#
# # Define the function based on the equation given
# def f(c):
#     return (g * m / c) * (1 - np.exp(-c * t / m)) - v
#
#
# # Implement the Bisection Method
# def bisection_method(func, a, b, tol=1e-5, max_iter=100):
#     if func(a) * func(b) >= 0:
#         print("Bisection method fails. The function should have opposite signs at a and b.")
#         return None, []
#
#     table_data = []  # To store iteration results for tabular display
#
#     for i in range(max_iter):
#         midpoint = (a + b) / 2.0
#         f_mid = func(midpoint)
#
#         # Store the iteration data
#         table_data.append([i + 1, a, b, midpoint, f_mid])
#
#         # Check if midpoint is close enough to the root
#         if abs(f_mid) < tol:
#             print(f"Root found at c = {midpoint} after {i + 1} iterations")
#             return midpoint, table_data
#         elif func(a) * f_mid < 0:
#             b = midpoint
#         else:
#             a = midpoint
#
#     print("Maximum iterations reached. Solution may not have converged.")
#     return midpoint, table_data
#
#
# # Initial interval for c
# a = 0.1  # Lower bound
# b = 1.0  # Upper bound
#
# # Find the root and retrieve iteration data
# root, table_data = bisection_method(f, a, b)
#
# # Display results in tabular format
# df = pd.DataFrame(table_data, columns=["Iteration", "a", "b", "Midpoint", "f(Midpoint)"])
# print(df)
#
# # Plotting the function and the midpoint values
# c_values = np.linspace(a, b, 100)
# f_values = [f(c) for c in c_values]
#
# plt.figure(figsize=(10, 6))
# plt.plot(c_values, f_values, label='f(c)')
# plt.axhline(0, color='gray', linestyle='--')
# plt.xlabel("Drag Coefficient (c)")
# plt.ylabel("f(c)")
# plt.title("Bisection Method to Find Drag Coefficient")
# plt.plot(df["Midpoint"], [f(mid) for mid in df["Midpoint"]], 'ro-', label='Midpoints per Iteration')
# plt.legend()
# plt.grid()
# plt.show()
'''

# 1. Use the Bisection Method to determine the drag coefficients ‘c’ needed for a Parachutist of mass
# m=68.1 kg to have a velocity of 40 m/s after free-falling for timer t=10 s after that Implement it by
# Python. In Python, Result must be shown both Graphical and Tabular format. Note: The acceleration
# due to gravity is 9.81 m/s2.
# The equation is f(c)=
# 𝒈𝒎
# 𝒂� (𝟎� − 𝒂�−( 𝒂�
# 𝒎)𝒓�) − 𝒗
import matplotlib.pyplot as plt
from tabulate import tabulate
import math


def bisection(func, a, b, tol=1e-6, max_iter=100):
    iterations = []
    a_values = []
    b_values = []
    c_values = []
    f_a_values = []
    f_b_values = []
    f_c_values = []

    # Check if the initial interval is valid
    if func(a) * func(b) >= 0:
        raise ValueError("The function must have opposite signs at a and b to apply the Bisection method.")

    # Bisection loop
    for i in range(max_iter):
        c = (a + b) / 2
        iterations.append(i)
        a_values.append(a)
        b_values.append(b)
        c_values.append(c)

        f_a = func(a)
        f_b = func(b)
        f_c = func(c)

        f_a_values.append(f_a)
        f_b_values.append(f_b)
        f_c_values.append(f_c)

        # Check for convergence
        if f_c == 0 or abs(b - a) / 2 < tol:
            break
        elif f_a * f_c < 0:
            b = c
        else:
            a = c

    # Prepare the results table
    results = list(zip(iterations, a_values, b_values, c_values, f_a_values, f_b_values, f_c_values))
    table = tabulate(results, headers=["Iteration", "a", "b", "c", "f(a)", "f(b)", "f(c)"], tablefmt="pretty")
    print(table)

    # Plotting the function
    x = [i / 10 for i in range(int(10 * min(a, b)) - 1, int(10 * max(a, b)) + 2)]
    y = [func(xi) for xi in x]
    plt.plot(x, y, label='f(x)')
    plt.axhline(0, color='red', linestyle='--', label='y=0')
    plt.axvline(c, color='green', linestyle='--', label='Root Approximation')
    plt.title('Bisection Method')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.legend()
    plt.grid(True)
    plt.show()

    return c


# Define the function to find the root for
def function(c):
    return ((667.38 / c) * (1 - math.exp(-0.146843 * c))) - 40


# Define interval and find the root
a = 12
b = 16
root = bisection(function, a, b)
print(f"The approximate root is: {root:.6f}")
