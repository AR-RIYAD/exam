# Solve the following system by the Gauss-Elimination method and Implement it using Python.
# 3x1+.1x2-.2x3 = 7.85
# .1x1+7x2-.3x3 = -19.3
# .3x1-2x2+10x3 = 71.4

import numpy as np

# Coefficients and constants
coefficients = np.array([[3, 0.1, -0.2],
                          [0.1, 7, -0.3],
                          [0.3, -2, 10]])
constants = np.array([7.85, -19.3, 71.4])

# Create the augmented matrix
augmented_matrix = np.column_stack((coefficients, constants))

# Perform Gaussian elimination
n = len(constants)
for i in range(n):
    augmented_matrix[i, :] = augmented_matrix[i, :] / augmented_matrix[i, i]
    for j in range(n):
        if i != j:
            augmented_matrix[j, :] -= augmented_matrix[j, i] * augmented_matrix[i, :]

# Extract solutions
solutions = augmented_matrix[:, -1]

# Output results
print("Solution:")
for i, sol in enumerate(solutions):
    print(f"x{i + 1} =", sol)
