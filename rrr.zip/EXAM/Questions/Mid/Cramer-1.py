# A total of 8,500 taka was invested in three interest earning accounts. The interest rates were 2%,3%
# and 6% if the total simple interest for one year was 380 taka and the amount invested at 6% was
# equal to the sum of the amounts in the other two accounts, then how much was invested in each
# account? (Use Cramer’s rule) and implement with python.

import numpy as np

# Coefficient matrix
coefficients = np.array([[1, 1, 1],
                          [2, 3, 6],
                          [1, 1, -1]])

# Constants array
constants = np.array([8500, 38000, 0])

# Determinant of the coefficient matrix
det_coefficients = np.linalg.det(coefficients)

# Create copies of the coefficient matrix for Cramer's Rule
coefficients_x = coefficients.copy()
coefficients_x[:, 0] = constants
coefficients_y = coefficients.copy()
coefficients_y[:, 1] = constants
coefficients_z = coefficients.copy()
coefficients_z[:, 2] = constants

# Determinants for each variable
det_x = np.linalg.det(coefficients_x)
det_y = np.linalg.det(coefficients_y)
det_z = np.linalg.det(coefficients_z)

# Solutions using Cramer's Rule
solution_x = det_x / det_coefficients
solution_y = det_y / det_coefficients
solution_z = det_z / det_coefficients

# Print the solutions
print("Solution:")
print(f"x = {solution_x}")
print(f"y = {solution_y}")
print(f"z = {solution_z}")
