# Using Cramer's rule solve the following after that implement it using Python.
# .3x1+.52x2+x3=0.01
# .5x1+.3x2+.5x3=.67
# .1x1+.3x2+.5x3=-.44

import numpy as np

# Coefficient matrix
coefficients = np.array([
    [0.3, 0.52, 1],
    [0.5, 0.3, 0.5],
    [0.1, 0.3, 0.5]
])

# Constants
constants = np.array([0.01, 0.67, -0.44])

# Calculate the determinant of the coefficient matrix
det_coefficients = np.linalg.det(coefficients)

# Create copies of the coefficient matrix to replace columns with constants
coefficients_x = coefficients.copy()
coefficients_x[:, 0] = constants

coefficients_y = coefficients.copy()
coefficients_y[:, 1] = constants

coefficients_z = coefficients.copy()
coefficients_z[:, 2] = constants

# Calculate the determinants of the modified matrices
det_x = np.linalg.det(coefficients_x)
det_y = np.linalg.det(coefficients_y)
det_z = np.linalg.det(coefficients_z)

# Calculate the solutions
solution_x = det_x / det_coefficients
solution_y = det_y / det_coefficients
solution_z = det_z / det_coefficients

# Print the solutions
print("Solution:")
print(f"x = {solution_x}")
print(f"y = {solution_y}")
print(f"z = {solution_z}")
