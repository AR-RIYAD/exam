# A total of ₹8,600 was invested in two accounts. One account earned 4 (3/4) % annual1 interest and
# the other earned 6 (1/2) % annual interest. If the total interest for one year was ₹431.25, how much
# was invested in each account? (Use Gauss-elimination Method and Implement by Python).

import numpy as np

# Coefficients and constants
coefficients = np.array([[1, 1], [19, 26]])
constants = np.array([8600, 172500])

# Create the augmented matrix
augmented_matrix = np.column_stack((coefficients, constants))
n = len(constants)

# Gaussian elimination
for i in range(n):
    augmented_matrix[i, :] = augmented_matrix[i, :] / augmented_matrix[i, i]
    for j in range(n):
        if i != j:
            augmented_matrix[j, :] -= augmented_matrix[j, i] * augmented_matrix[i, :]

# Extract solutions
solutions = augmented_matrix[:, -1]

# Output results
print("Number of T-shirts (x):", solutions[0])
print("Number of Hoodies (y):", solutions[1])
