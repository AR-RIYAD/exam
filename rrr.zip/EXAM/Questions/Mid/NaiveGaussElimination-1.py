# to infer the surface of an object from images taken of a surface from three different directions, one needs to solve the following set of equations. 0.2425X1-0.9701X3= 247, 0.2425X2-0.9701X3=248, -0.2357X1-0.2357X2-0.9428X3=239. The right hand side values are the light intensities
# from the middle of the images, while the coefficient matrix is dependent on the light source directions with respect to the camera. The unknowns are the incident intensities that will determine the shape of the object. Find the values of X1, X2 and X3 using naive gauss elimination method in python
# import numpy as np
#
# def gauss_elimination(A, B):
#     """Naive Gauss elimination without pivoting to solve Ax = B."""
#     n = len(B)
#
#     # Forward elimination
#     for i in range(n):
#         for j in range(i+1, n):
#             factor = A[j][i] / A[i][i]
#             for k in range(i, n):
#                 A[j][k] -= factor * A[i][k]
#             B[j] -= factor * B[i]
#
#     # Back substitution
#     x = [0 for _ in range(n)]
#     for i in range(n-1, -1, -1):
#         x[i] = B[i]
#         for j in range(i+1, n):
#             x[i] -= A[i][j] * x[j]
#         x[i] = x[i] / A[i][i]
#
#     return x
#
# # Coefficient matrix A
# A = [
#     [0.2425, 0, -0.9701],
#     [0, 0.2425, -0.9701],
#     [-0.2357, -0.2357, -0.9428]
# ]
#
# # Right-hand side vector B
# B = [247, 248, 239]
#
# # Solve using Gauss elimination
# solution = gauss_elimination(A, B)
# X1, X2, X3 = solution
#
# print(f"X1 = {X1:.4f}")
# print(f"X2 = {X2:.4f}")
# print(f"X3 = {X3:.4f}")

# with graph
import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate

def gauss_elimination(A, B):
    """Naive Gauss elimination without pivoting to solve Ax = B."""
    n = len(B)

    # Forward elimination
    for i in range(n):
        for j in range(i + 1, n):
            factor = A[j][i] / A[i][i]
            for k in range(i, n):
                A[j][k] -= factor * A[i][k]
            B[j] -= factor * B[i]

    # Back substitution
    x = [0 for _ in range(n)]
    for i in range(n - 1, -1, -1):
        x[i] = B[i]
        for j in range(i + 1, n):
            x[i] -= A[i][j] * x[j]
        x[i] = x[i] / A[i][i]

    return x

# Coefficient matrix A
A = [
    [0.2425, 0, -0.9701],
    [0, 0.2425, -0.9701],
    [-0.2357, -0.2357, -0.9428]
]

# Right-hand side vector B
B = [247, 248, 239]

# Solve using Gauss elimination
solution = gauss_elimination(A, B)
X1, X2, X3 = solution

# Prepare the results for tabular display
results = [["Variable", "Value"],
           ["X1", f"{X1:.4f}"],
           ["X2", f"{X2:.4f}"],
           ["X3", f"{X3:.4f}"]]

# Print the results in tabular format
print(tabulate(results, headers="firstrow", tablefmt="pretty"))

# Plotting the results
variables = ['X1', 'X2', 'X3']
values = [X1, X2, X3]

plt.bar(variables, values, color=['blue', 'orange', 'green'])
plt.ylabel('Intensity')
plt.title('Incident Intensities')
plt.grid(axis='y')
plt.ylim(0, max(values) + 5)  # Set y-axis limit for better visibility
plt.axhline(0, color='black', linewidth=0.8)  # Add x-axis line at y=0
plt.show()
