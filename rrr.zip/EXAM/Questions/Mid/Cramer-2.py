# In a market survey three commodities A, B and C were considered. In finding out the index number
# some fixed weights were assigned to the three varieties in each of the commodities. The table below
# provides the information regarding the consumption of three commodities according to the three
# varieties and also the total weight received by the commodity.

import numpy as np

# Coefficient matrix
coefficients = np.array([[1, 2, 3],
                          [2, 4, 5],
                          [3, 5, 6]])

# Constants array
constants = np.array([11, 21, 27])

# Determinant of the coefficient matrix
det_coefficients = np.linalg.det(coefficients)

# Create copies of the coefficient matrix for Cramer's Rule
coefficients_x = coefficients.copy()
coefficients_x[:, 0] = constants

coefficients_y = coefficients.copy()
coefficients_y[:, 1] = constants

coefficients_z = coefficients.copy()
coefficients_z[:, 2] = constants

# Determinants for each variable
det_x = np.linalg.det(coefficients_x)
det_y = np.linalg.det(coefficients_y)
det_z = np.linalg.det(coefficients_z)

# Solutions using Cramer's Rule
solution_x = det_x / det_coefficients
solution_y = det_y / det_coefficients
solution_z = det_z / det_coefficients

# Print the solutions
print("Solution:")
print(f"x = {solution_x}")
print(f"y = {solution_y}")
print(f"z = {solution_z}")
