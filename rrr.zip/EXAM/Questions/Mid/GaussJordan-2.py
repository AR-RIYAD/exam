# Solve the following system by the Gauss-Jordan method and Implement it using
# Python.
# 3x1-0.1x2-0.2x3=7.85
# 0.1x1+7x2-0.3x3=-19.3
# 0.3x1-0.2x2+10x3=71.4

import numpy as np

# Coefficients matrix
coefficients = np.array([[3, -0.1, -0.2],
                         [0.1, 7, -0.3],
                         [0.3, -0.2, 10]])
constants = np.array([7.85, -19.3, 71.4])

# Augmented matrix
augmented_matrix = np.column_stack((coefficients, constants))
rows, cols = augmented_matrix.shape

# Applying Gauss-Jordan elimination
for i in range(rows):
    # Normalize the pivot row
    augmented_matrix[i] = augmented_matrix[i] / augmented_matrix[i, i]

    # Eliminate other rows
    for j in range(rows):
        if i != j:
            augmented_matrix[j] = augmented_matrix[j] - augmented_matrix[j, i] * augmented_matrix[i]

# Extract the solution
solution = augmented_matrix[:, -1]

# Print the solution
print("Solution:")
for i, value in enumerate(solution):
    print(f"x{i + 1} = {value}")
