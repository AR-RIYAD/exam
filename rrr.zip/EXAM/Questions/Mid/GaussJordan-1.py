# An investor has $10,000 to invest in two types of financial instruments: stocks and
# bonds. The expected return from stocks is 8%, and from bonds is 5%. The investor
# wants the total return to be $700. Find the amount invested in each type Using
# Gauss-Jordan method after that implement it using Python.

import numpy as np

# Coefficients matrix
coefficients = np.array([[0.08, 0.05], [1, 1]])

# Constants vector
constants = np.array([700, 10000])

# Augmented matrix
augmented_matrix = np.column_stack((coefficients, constants))

# Applying Gauss-Jordan elimination
rows, cols = augmented_matrix.shape
for i in range(rows):
    # Normalize the pivot row
    augmented_matrix[i] = augmented_matrix[i] / augmented_matrix[i, i]
    # Eliminate other rows
    for j in range(rows):
        if i != j:
            augmented_matrix[j] = augmented_matrix[j] - augmented_matrix[j, i] * augmented_matrix[i]

# Extract the solution
solution = augmented_matrix[:, -1]

# Print the solution
print("Amount invested in stocks:", solution[0])
print("Amount invested in bonds:", solution[1])
