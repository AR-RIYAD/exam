# Suppose You are a financial analyst tasked with estimating the remaining value of a piece
# of equipment as it depreciates over time. The asset has an initial value (V0) of $50,000, and
# its value decreases exponentially over time. The depreciation model is given by the formula:
# V(t+1) = V(t)⋅(1−d)
# V(t) is the value of the equipment at time t, the depreciation rate is 3%. In Python result
# must be shown both Console panel and Graphically.
# [Maximum number of iterations: 100]

import matplotlib.pyplot as plt


def f(V, d):
    return V * (1 - d)


def simple_fixed_point_iteration(V0, d, iterations):
    values = [V0]
    for i in range(iterations):
        V1 = f(V0, d)
        values.append(V1)

        # Check for convergence
        if abs(V1 - V0) < 1e-8:
            break

        V0 = V1  # Update for the next iteration

    return values


# Parameters
V0 = 50000  # Initial value of the equipment
d = 0.03  # Depreciation rate
iterations = 100  # Maximum number of iterations

# Running the fixed-point iteration
estimated_values = simple_fixed_point_iteration(V0, d, iterations)

# Plotting the results
plt.plot(range(len(estimated_values)), estimated_values, marker='o')
plt.title('Depreciation Over Time')
plt.xlabel('Time (iterations)')
plt.ylabel('Equipment Value')
plt.grid(True)
plt.show()

# Output the estimated long-term value
print("Estimated long-term value of the equipment:", estimated_values[-1])
