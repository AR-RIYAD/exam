# Suppose you are involved in a manufacturing process, and you want to optimize the
# temperature setting for a chemical reaction to maximize the yield of a certain product. The
# rate of the chemical reaction (R) is temperature-dependent and is given by the Arrhenius
# equation:
# R=A. 𝒂�− 𝑬
# 𝑹𝑻
# where: The pre-exponential factor is A = 2.5x108, the activation energy E = 50000, the ideal
# gas constant R = 8.314 j/mol/k, the initial temperature in Kelvin T0 = 300. [iteration is 10]
# You need to find the optimal temperature (T) that maximizes the rate of the chemical
# reaction. Use the Newton-Raphson method to find the root of the equation by
# Implementing with Python.


import math


def f(T, A, E, R, target_R):
    return A * math.exp(-E / (R * T)) - target_R


def df_dT(T, A, E, R):
    return (A * E / (R * T ** 2)) * math.exp(-E / (R * T))


def newton_raphson_method(T0, A, E, R, target_R, iterations):
    for i in range(iterations):
        f_T0 = f(T0, A, E, R, target_R)
        df_dT0 = df_dT(T0, A, E, R)

        # Update the temperature using the Newton-Raphson formula
        T1 = T0 - f_T0 / df_dT0

        # Check for convergence
        if abs(T1 - T0) < 1e-8:
            break

        T0 = T1  # Update for the next iteration

    return T1


# Parameters
A = 2.5e8  # Pre-exponential factor
E = 50000  # Activation energy (in Joules per mole)
R = 8.314  # Ideal gas constant (in J/(mol*K))
target_R = 1  # Target reaction rate
T0 = 300  # Initial temperature guess (in Kelvin)
iterations = 10  # Maximum number of iterations

# Finding the optimal temperature
optimal_temperature = newton_raphson_method(T0, A, E, R, target_R, iterations)
print("Optimal temperature:", optimal_temperature, "Kelvin")

