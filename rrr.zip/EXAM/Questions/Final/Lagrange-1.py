# Consider a problem involving temperature data at various locations and times. Suppose you
# have temperature measurements at different locations (represented by x-values) and times
# (represented by y-values). You want to interpolate the temperature at a specific location and
# time that falls between the measured data points.
# Consider the locations: [0,10,20,30] and temperatures: [25,20,15,10] and the target location is
# 16.
# You need to solve it using Lagrange Interpolation formula and Implement by Python. Result
# must be shown in both console panel and Graphically.

import matplotlib.pyplot as plt

def lagrange_interpolation(x_values, y_values, x):
    n = len(x_values)
    result = 0.0
    for i in range(n):
        term = y_values[i]
        for j in range(n):
            if i != j:
                term *= (x - x_values[j]) / (x_values[i] - x_values[j])
        result += term
    return result

# Measured data
locations = [0, 10, 20, 30]
temperatures = [25, 20, 15, 10]

# Target location for interpolation
target_location = 16
interpolated_temperature = lagrange_interpolation(locations, temperatures, target_location)

# Print the interpolated temperature
print(f"Interpolated temperature at {target_location} km: {interpolated_temperature:.2f}°C")

# Plotting
plt.scatter(locations, temperatures, label='Measured Data', color='blue')
plt.plot(target_location, interpolated_temperature, 'ro', label='Interpolated Value')
plt.xlabel('Location (km)')
plt.ylabel('Temperature (°C)')
plt.title('Temperature Interpolation using Lagrange Polynomial')
plt.legend()
plt.grid()
plt.show()
