# Newton's Law of Cooling characterizes the temporal evolution of an object's temperature
# as a function of its surrounding environment. The differential equation associated with this
# phenomenon is expressed as
# 𝒂�𝑻
# 𝒂�𝒓� = −𝒌(𝑻 − 𝑻𝒂𝒎𝒂�𝒊𝒂�𝒎�𝒓�). Where T represents the temperature
# of the object, t is the time variable, k denotes the cooling constant, and Tambient is the ambient
# temperature. This equation signifies that the rate of temperature change
# 𝒂�𝑻
# 𝒂�𝒓� if proportional
# to the temperature difference between the object and its surroundings. As an illustrative
# example, consider a hot cup of coffee (T0=90oC) in a room with an ambient temperature of
# Tambient=200 C. Employing Heun's method with a step size of ℎ=1 min we can approximate the
# temperature evolution over a time span of 30 min (t0= 0 min, tend= 30 min) with a cooling
# constant k=0.02, This simulation provides insights into how the coffee cools down toward
# the room temperature, offering a practical application of Newton's Law of Cooling with
# specific initial conditions and parameters.

import matplotlib.pyplot as plt


def newtons_law_of_cooling(t, T, k, T_ambient):
    return -k * (T - T_ambient)


def heuns_method(f, t0, T0, tn, h, k, T_ambient):
    t_values = [t0]
    T_values = [T0]
    num_steps = int((tn - t0) / h)

    for i in range(1, num_steps + 1):
        t_n = t_values[i - 1]
        T_n = T_values[i - 1]

        # Predictor step
        T_pred = T_n + h * f(t_n, T_n, k, T_ambient)

        # Corrector step
        T_corrected = T_n + 0.5 * h * (f(t_n, T_n, k, T_ambient) +
                                       f(t_n + h, T_pred, k, T_ambient))

        t_next = t_n + h
        t_values.append(t_next)
        T_values.append(T_corrected)

    return t_values, T_values


# Parameters
t0 = 0  # Initial time (minutes)
T0 = 90  # Initial temperature of the coffee (°C)
tn = 30  # Final time (minutes)
h = 1  # Time step size (minutes)
k = 0.02  # Cooling constant
T_ambient = 20  # Ambient temperature (°C)

# Calculate temperatures over time using Heun's method
t_values, T_values = heuns_method(newtons_law_of_cooling, t0, T0, tn, h, k, T_ambient)

# Plotting the results
plt.plot(t_values, T_values, label="Temperature of Coffee")
plt.axhline(y=T_ambient, color='r', linestyle='--', label="Ambient Temperature")
plt.xlabel('Time (minutes)')
plt.ylabel('Temperature (°C)')
plt.title("Newton's Law of Cooling: Coffee Cooling in a Room")
plt.legend()
plt.grid(True)
plt.show()
