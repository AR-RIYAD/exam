# Consider a problem where we want to calculate the probability of an event occurring
# within a certain range in a normal distribution. For instance, let's say we have a dataset
# representing the heights of individuals in a population, and we want to find the probability
# of selecting an individual with a height between -1 standard deviation and +1 standard
# deviation from the mean.
# In this case, the Gaussian distribution 𝑒−𝑥2can represent the probability density function
# (PDF) of the heights in the population. The integral of this function over the range [−1,1]
# using Simpson's 1/3 rule can be interpreted as the probability of selecting an individual
# with a height within one standard deviation from the mean.[n=6].

import math


def simpsons_one_third_rule(func, a, b, n):
    h = (b - a) / n
    result = func(a) + func(b)

    # Add 4 * f(x) for odd indices
    for i in range(1, n, 2):
        result += 4 * func(a + i * h)

    # Add 2 * f(x) for even indices
    for i in range(2, n - 1, 2):
        result += 2 * func(a + i * h)

    result *= h / 3
    return result


def exponential_function(x):
    return math.exp(-x ** 2)


# Define the limits and number of intervals
lower_limit = -1
upper_limit = 1
num_intervals = 6

# Calculate the approximate integral
approx_integral = simpsons_one_third_rule(exponential_function, lower_limit, upper_limit, num_intervals)

# Print the result
print(f"Approximate integral: {approx_integral:.6f}")
