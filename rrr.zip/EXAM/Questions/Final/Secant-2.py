# Imagine you are designing a physics simulation, and you need to find the time(t) it takes for
# a projectile to hit the ground. The vertical position of the projectile is modeled by the
# quadratic equation:
# h(t)=−5t2+10t+15
# You need to find the time at which the projectile hits the ground ((h(t)=0) using the secant
# method by implementing Python. [N.B: Consider the Initial guess 1,2 and maximum
# iterations is 10]

def h(t):
    return -5 * t ** 2 + 10 * t + 15


def secant_method(t0, t1, iterations):
    for i in range(iterations):
        ht0 = h(t0)
        ht1 = h(t1)
        # Secant formula
        t2 = t1 - (t1 - t0) / (ht1 - ht0) * ht1

        # Check for convergence
        if abs(t2 - t1) < 1e-8:
            break

        t0, t1 = t1, t2  # Update points

    return t2


# Initial guesses
t0 = 1
t1 = 2
iterations = 10

# Finding the time of impact
time_of_impact = secant_method(t0, t1, iterations)
print("Time of impact:", time_of_impact, "seconds")
