import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Set a random seed for reproducibility
np.random.seed(42)

# Generate random data
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X + np.random.randn(100, 1)

# Create and fit the model
model = LinearRegression()
model.fit(X, y)

# Prepare new data for predictions
X_new = np.array([[0], [2]])
y_pred = model.predict(X_new)

# Plot the original data and the regression line
plt.scatter(X, y, label='Original data')
plt.plot(X_new, y_pred, 'r-', label='Regression line')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.show()

# Print the intercept and slope
print('Intercept (beta_0):', model.intercept_[0])
print('Slope (beta_1):', model.coef_[0][0])
