# Consider a scenario where y represents the population of a substance, and x represents
# time. The negative sign indicates a decrease in the quantity over time. This could model the
# decay of a radioactive substance, the cooling of a hot object, or the decrease in the number
# of individuals in a population due to natural factors. It is expressed by equation as:
# 𝒂�𝒙�
# 𝒂�𝒙 = −𝒙�
# Let's use this interpretation and plot the solution to the differential equation over time with
# implementing Milne’s Predictor-corrector method, assuming y(0)=1 and x ranging from 0 to
# 10 with a step size of 0.5. In Python result must be shown both console panel and
# Graphically.

import numpy as np
import matplotlib.pyplot as plt


def milnes_method(f, y0, x0, x_end, h):
    x = np.arange(x0, x_end + h, h)
    y_predictor = np.zeros(len(x))
    y_corrector = np.zeros(len(x))

    y_predictor[0] = y0
    y_corrector[0] = y0

    for i in range(1, len(x)):
        # Predictor step
        y_pred = y_corrector[i - 1] + h * f(x[i - 1], y_corrector[i - 1])
        # Corrector step
        y_corrected = y_corrector[i - 1] + (h / 4) * (3 * f(x[i], y_pred) - f(x[i - 1], y_corrector[i - 1]))

        y_predictor[i] = y_pred
        y_corrector[i] = y_corrected

    return x, y_predictor, y_corrector


def f(x, y):
    return -y  # Example: exponential decay


# Initial conditions
y0 = 1
x0 = 0
x_end = 10
h = 0.5

# Apply Milne's method
x, y_predictor, y_corrector = milnes_method(f, y0, x0, x_end, h)

# Print results
for i in range(len(x)):
    print(f"At x = {x[i]:.1f}, Predictor y = {y_predictor[i]:.4f}, Corrector y = {y_corrector[i]:.4f}")

# Plotting the results
plt.plot(x, y_predictor, label='Predictor Step', marker='o')
plt.plot(x, y_corrector, label='Corrector Step', marker='x')
plt.xlabel('Time (x)')
plt.ylabel('Population (y)')
plt.title('Milne\'s Predictor-Corrector Method for Exponential Decay')
plt.legend()
plt.grid()
plt.show()
