# Consider a problem involving radioactive decay. The decay of a radioactive substance can be
# modeled by a first-order differential equation of the form dt/dy=−k⋅y. Where y is the quantity
# of the substance, t is time, and k is the decay constant.

import matplotlib.pyplot as plt


def radioactive_decay(t, y):
    k = 0.01  # Decay constant
    return -k * y


def euler_method(f, t0, y0, tn, h):
    t_values = [t0]
    y_values = [y0]
    num_steps = int((tn - t0) / h)

    for i in range(1, num_steps + 1):
        t_next = t_values[i - 1] + h
        y_next = y_values[i - 1] + h * f(t_values[i - 1], y_values[i - 1])
        t_values.append(t_next)
        y_values.append(y_next)

    return t_values, y_values


# Initial conditions
t0 = 0
y0 = 1000  # Initial quantity of radioactive substance
tn = 50  # End time
h = 1  # Step size

# Solve the ODE using Euler's method
t_values, y_values = euler_method(radioactive_decay, t0, y0, tn, h)

# Plotting the results
plt.plot(t_values, y_values, label='Radioactive Decay', color='blue')
plt.xlabel('Time (t)')
plt.ylabel('Quantity of Substance (y)')
plt.title('Radioactive Decay ODE Solution using Euler\'s Method')
plt.legend()
plt.grid()
plt.show()
