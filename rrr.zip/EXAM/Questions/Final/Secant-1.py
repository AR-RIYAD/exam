# Suppose you are developing a computer graphics application, and you need to find the root
# of a polynomial function that represents the position of a moving object at a specific time.
# The polynomial function is given by:
# F(x)=2x3-4x2-6x+3
# You need to find a solution to the equation F(x)=0 to determine the time when the object
# reaches a certain position. Use the secant method to find the root of the equation by
# implementing it with Python. [N.B: Consider the Initial guess 1, 3 and iterations is 10]

def f(x):
    return 2 * x ** 3 - 4 * x ** 2 - 6 * x + 3


def secant_method(x0, x1, iterations):
    for i in range(iterations):
        fx0 = f(x0)
        fx1 = f(x1)
        # Secant formula
        x2 = x1 - (x1 - x0) / (fx1 - fx0) * fx1

        # Check for convergence
        if abs(x2 - x1) < 1e-8:
            break

        x0, x1 = x1, x2  # Update points

    return x2


# Initial guesses
x0 = 1
x1 = 3
iterations = 10

# Finding the root
root = secant_method(x0, x1, iterations)
print("Root of the polynomial:", root)
