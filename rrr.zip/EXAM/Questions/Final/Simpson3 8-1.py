# Imagine you are calculating the work done by a variable force F(x) to move an object along
# a straight path from x=1 to x=2. The force is given by F(x)=x3, and you need to find the work
# done over this displacement. Implement the calculation using Python with Simpson’s
# 3/8 rule.[number of intervals,n=3]

def simpsons_three_eighth_rule(func, a, b, n):
    if n % 3 != 0:
        raise ValueError("Number of intervals n must be a multiple of 3.")

    h = (b - a) / n
    result = func(a) + func(b)

    # Sum for the inner points with weights
    for i in range(1, n, 3):
        result += 3 * (func(a + i * h) + func(a + (i + 1) * h))

    result *= 3 * h / 8
    return result


def cubic_function(x):
    return x ** 3


# Define the limits and number of intervals
lower_limit = 1
upper_limit = 2
num_intervals = 3

# Calculate the approximate integral
approx_integral = simpsons_three_eighth_rule(cubic_function, lower_limit, upper_limit, num_intervals)

# Print the result
print(f"Approximate integral: {approx_integral:.6f}")
