import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Set random seed for reproducibility
np.random.seed(42)

# Generate synthetic data
size = np.random.uniform(1000, 5000, 100)
price = 100000 + 150 * size - 0.05 * (size ** 2) + np.random.normal(0, 5000, 100)

# Reshape data
size = size.reshape(-1, 1)
price = price.reshape(-1, 1)

# Split the data into training and testing sets
size_train, size_test, price_train, price_test = train_test_split(size, price, test_size=0.2, random_state=42)

# Polynomial features
degree = 2
poly = PolynomialFeatures(degree=degree)
size_poly = poly.fit_transform(size_train)

# Fit the model
model = LinearRegression()
model.fit(size_poly, price_train)

# Predict on training data
price_train_pred = model.predict(size_poly)

# Plot the training data and the polynomial regression line
plt.scatter(size_train, price_train, color='blue', label='Training data')
plt.plot(size_train, price_train_pred, color='red', label='Polynomial regression')
plt.title('Polynomial Regression - House Prices')
plt.xlabel('Size')
plt.ylabel('Price')
plt.legend()
plt.show()

# Transform test data and predict
size_test_poly = poly.transform(size_test)
price_test_pred = model.predict(size_test_poly)

# Calculate Mean Squared Error
mse = mean_squared_error(price_test, price_test_pred)
print(f'Mean Squared Error on Test Data: {mse}')

# Predict price for a new house
new_size = np.array([[3000]])
new_size_poly = poly.transform(new_size)
predicted_price = model.predict(new_size_poly)
print(f'Predicted Price for a new house: {predicted_price[0][0]}')
