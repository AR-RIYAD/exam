# Imagine you are studying the population growth of a species in a controlled environment.
# The population (P) at any given time is influenced by the rate of growth (r) and the initial
# population (P0). The population growth can be modeled by the differential equation:
# P(t)=P0 + ∫ 𝒓. 𝑷(𝒓�) 𝒂�𝒓�
# 𝟎𝒓�
# Implement it Using Picard's Method to find an approximate solution for P(t) with an initial
# guess P0(t) = 10 and growth rate r=0.1. Growth rate must be shown in a graph.

import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

def integral_equation(P, t, r):
    return 10 + integrate.quad(lambda s: r * P, 0, t)[0]

def picards_method(P0, t, r, iterations):
    for i in range(iterations):
        P1 = np.vectorize(integral_equation)(P0, t, r)
        if np.all(np.abs(P1 - P0) < 1e-8):
            break
        P0 = P1
    return P1

# Define time values and parameters
t_values = np.linspace(0, 5, 100)
initial_guess = 10  # Initial population
growth_rate = 0.1
iterations = 10

# Apply Picard's method
population_solution = picards_method(initial_guess, t_values, growth_rate, iterations)

# Plotting the results
plt.plot(t_values, population_solution, label='Approximate Population')
plt.xlabel('Time (t)')
plt.ylabel('Population (P)')
plt.title("Population Growth Using Picard's Method")
plt.legend()
plt.grid()
plt.show()
