# Use bisection and false position
# to locate the root of f(x)=x^10-1 between x=0 and 1.3

def false_position_method(func, a, b, tol=1e-6, max_iter=100):
    if func(a) * func(b) > 0:
        raise ValueError("The function must have different signs at the interval endpoints.")

    iterations = 0
    while iterations < max_iter:
        c = (a * func(b) - b * func(a)) / (func(b) - func(a))

        if abs(func(c)) < tol:
            return c, iterations

        if func(c) * func(a) < 0:
            b = c
        else:
            a = c

        iterations += 1

    raise ValueError("False-position method did not converge within the maximum number of iterations.")


# Example usage
def example_function(x):
    return x ** 10 - 1


a = 0
b = 1.3
tolerance = 1e-6

# Find the root
root, iterations = false_position_method(example_function, a, b, tol=tolerance)

# Print the results
print(f"Approximated root: {root:.6f}")
print(f"Iterations: {iterations}")
