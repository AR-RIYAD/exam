from itertools import product

# Define function to print truth tables
def print_truth_table(statement_name, expression, variables):
    print(f"Truth Table for '{statement_name}':")
    print(" | ".join(variables) + " | Result")
    print("-" * (len(variables) *10))

    # Generate all possible truth values
    for values in product([True, False], repeat=len(variables)):
        # Create a dictionary of variable assignments
        context = dict(zip(variables, values))
        result = expression(**context)
        row = " | ".join(str(v) for v in values) + " | " + str(result)
        print(row)
    print("\n")

# Define propositions as lambda functions
propositions = [
    ("A. It is raining outside if and only if it is a cloudy day",
     lambda p, q: p == q, ["p", "q"]),
    ("B. If you get a 100 on the final exam, then you can earn an A in the class",
     lambda p, q: (not p) or q, ["p", "q"]),
    ("C. Take either 2 Advil or 3 Tylenol",
     lambda p, q: p != q, ["p", "q"]),
    ("D. She studied hard or she is extremely bright",
     lambda p, q: p or q, ["p", "q"]),
    ("E. I am a rock and I am an Iceland",
     lambda p, q: p and q, ["p", "q"])
]

# Print each truth table
for statement_name, expression, variables in propositions:
    print_truth_table(statement_name, expression, variables)