from itertools import product

# Define logical operations
def implies(p, q):
    return not p or q  # p -> q is equivalent to ¬p ∨ q

def biconditional(p, q):
    return p == q  # p <-> q is true if p and q are both the same

# Generate truth table for a given logical expression
def print_truth_table(expression, labels):
    print(f"\nTruth Table for: {' '.join(labels)}")
    print(" | ".join(labels) + " | Result")
    print("-" * (len(labels) * 4 + 8))
    for values in product([True, False], repeat=len(labels)):
        result = expression(*values)
        row = " | ".join(map(lambda x: str(x), values)) + f" | {result}"
        print(row)

# Propositions
# A: It is raining outside if and only if it is a cloudy day (p <-> q)
print_truth_table(biconditional, ["It is raining outside", "It is a cloudy day"])

# B: If you get a 100 on the final exam, then you can earn an A in the class (p -> q)
print_truth_table(implies, ["You get a 100 on the final exam", "You can earn an A in the class"])

# C: Take either 2 Advil or 3 Tylenol (p OR q)
print_truth_table(lambda p, q: p or q, ["Take 2 Advil", "Take 3 Tylenol"])

# D: She studied hard or she is extremely bright (p OR q)
print_truth_table(lambda p, q: p or q, ["She studied hard", "She is extremely bright"])

# E: I am a rock and I am an Iceland (p AND q)
print_truth_table(lambda p, q: p and q, ["I am a rock", "I am an Iceland"])