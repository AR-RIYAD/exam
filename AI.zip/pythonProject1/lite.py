print("Hello mike")
# Define the Parent predicate as a dictionary
parent = {
    ("John", "Mary"): True,
    ("Mary", "Joe"): True
}

# Define the function to check if x is a parent of y
def is_parent(x, y):
    return parent.get((x, y), False)

# Define the function to check if x is a grandparent of z
def is_grandparent(x, z):
    # If there exists a 'y' such that x is a parent of y and y is a parent of z, then x is a grandparent of z
    for y in parent:
        if is_parent(x, y[1]) and is_parent(y[1], z):
            return True
    return False

# Test the grandparent relationship between John and Joe
if is_grandparent("John", "Joe"):
    print("John is the grandparent of Joe.")
else:
    print("John is not the grandparent of Joe.")