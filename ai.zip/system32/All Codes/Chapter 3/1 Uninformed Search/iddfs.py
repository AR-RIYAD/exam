class Node:
    """Class to represent a node in the search tree."""

    def __init__(self, value):
        self.value = value
        self.children = []

    def add_child(self, child_node):
        self.children.append(child_node)


def depth_limited_dfs(node, goal, depth):
    """Perform depth-limited depth-first search."""
    if depth == 0 and node.value == goal:
        return True
    elif depth > 0:
        for child in node.children:
            if depth_limited_dfs(child, goal, depth - 1):
                return True
    return False


def iterative_deepening_dfs(root, goal):
    """Iterative deepening depth-first search."""
    depth = 0
    while True:
        print(f"Searching at depth: {depth}")
        if depth_limited_dfs(root, goal, depth):
            return True
        depth += 1


# Example usage
if __name__ == "__main__":
    # Creating a simple tree
    root = Node(1)
    child1 = Node(2)
    child2 = Node(3)
    child3 = Node(4)

    root.add_child(child1)
    root.add_child(child2)
    child1.add_child(child3)

    # Adding more nodes for a deeper tree
    child1.add_child(Node(5))
    child2.add_child(Node(6))
    child2.add_child(Node(7))
    child3.add_child(Node(8))

    # Searching for a goal node
    goal_value = 8
    found = iterative_deepening_dfs(root, goal_value)

    if found:
        print(f"Goal {goal_value} found!")
    else:
        print(f"Goal {goal_value} not found.")
