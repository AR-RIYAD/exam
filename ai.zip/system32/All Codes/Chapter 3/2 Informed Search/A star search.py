import heapq

class Node:
    """A node class for A* search."""
    def __init__(self, position, parent=None):
        self.position = position  # (x, y) position
        self.parent = parent  # Parent node
        self.g = 0  # Cost from start to current node
        self.h = 0  # Estimated cost from current node to goal (heuristic)
        self.f = 0  # Total cost (g + h)

    def __lt__(self, other):
        return self.f < other.f  # For priority queue

def a_star_search(grid, start, goal):
    """Perform A* search on the grid."""
    open_list = []  # Nodes to be evaluated
    closed_list = set()  # Nodes already evaluated

    # Create start and goal nodes
    start_node = Node(start)
    goal_node = Node(goal)

    # Add the start node to the open list
    heapq.heappush(open_list, start_node)

    while open_list:
        # Get the node with the lowest f value
        current_node = heapq.heappop(open_list)

        # If we reached the goal, reconstruct the path
        if current_node.position == goal_node.position:
            path = []
            while current_node:
                path.append(current_node.position)
                current_node = current_node.parent
            return path[::-1]  # Return reversed path

        closed_list.add(current_node.position)

        # Generate children nodes
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent squares (up, down, left, right)
            node_position = (current_node.position[0] + new_position[0], current_node.position[1] + new_position[1])

            # Check if within bounds
            if (0 <= node_position[0] < len(grid)) and (0 <= node_position[1] < len(grid[0])):
                # Check if the node is walkable
                if grid[node_position[0]][node_position[1]] == 1:
                    continue  # Skip obstacles

                # Create new node
                child_node = Node(node_position, current_node)

                # Check if child is in closed list
                if child_node.position in closed_list:
                    continue

                # Calculate g, h, and f values
                child_node.g = current_node.g + 1
                child_node.h = (goal_node.position[0] - child_node.position[0]) ** 2 + (goal_node.position[1] - child_node.position[1]) ** 2
                child_node.f = child_node.g + child_node.h

                # Check if child is in open list
                if add_to_open(open_list, child_node):
                    heapq.heappush(open_list, child_node)

    return None  # No path found

def add_to_open(open_list, child_node):
    """Check if child node should be added to the open list."""
    for node in open_list:
        if child_node.position == node.position and child_node.g >= node.g:
            return False
    return True

def print_path(grid, path):
    """Print the grid with the path marked."""
    for row in grid:
        print(" ".join(str(cell) for cell in row))
    print()

# Example grid
grid = [
    [0, 0, 0, 0, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 1, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 0, 0, 0]
]

start = (0, 0)  # Starting position
goal = (4, 4)   # Goal position

path = a_star_search(grid, start, goal)
if path:
    print("Path found:")
    print(path)
else:
    print("No path found.")
