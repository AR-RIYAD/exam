import heapq


class PuzzleState:
    def __init__(self, board, moves=0, previous=None):
        self.board = board  # 3x3 board represented as a list of lists
        self.moves = moves  # Number of moves taken to reach this state
        self.previous = previous  # Pointer to the previous state for reconstruction

    def __lt__(self, other):
        return self.priority() < other.priority()

    def priority(self):
        # A* Priority = number of moves + Manhattan distance
        return self.moves + self.manhattan()

    def manhattan(self):
        """Calculate the Manhattan distance of the current board configuration to the goal."""
        distance = 0
        goal_positions = {
            1: (0, 0), 2: (0, 1), 3: (0, 2),
            4: (1, 0), 5: (1, 1), 6: (1, 2),
            7: (2, 0), 8: (2, 1), 0: (2, 2)
        }

        for i in range(3):
            for j in range(3):
                tile = self.board[i][j]
                if tile != 0:  # Don't count distance for the empty space
                    goal_x, goal_y = goal_positions[tile]
                    distance += abs(goal_x - i) + abs(goal_y - j)

        return distance

    def is_goal(self):
        """Check if the current board is in the goal state."""
        return self.board == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

    def neighbors(self):
        """Generate neighboring states by sliding tiles."""
        neighbors = []
        # Find the empty space (0)
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == 0:
                    empty_x, empty_y = i, j

        # Possible moves: up, down, left, right
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for dx, dy in directions:
            x, y = empty_x + dx, empty_y + dy
            if 0 <= x < 3 and 0 <= y < 3:
                # Swap empty space with the neighboring tile
                new_board = [row[:] for row in self.board]
                new_board[empty_x][empty_y], new_board[x][y] = new_board[x][y], new_board[empty_x][empty_y]
                neighbors.append(PuzzleState(new_board, self.moves + 1, self))

        return neighbors

    def path(self):
        """Return the sequence of boards from the initial state to the current state."""
        state, path = self, []
        while state:
            path.append(state.board)
            state = state.previous
        return path[::-1]


def solve_puzzle(initial_board):
    """Solve the 8-puzzle problem using A* search algorithm."""
    initial_state = PuzzleState(initial_board)
    if initial_state.is_goal():
        return initial_state.path()

    priority_queue = []
    heapq.heappush(priority_queue, initial_state)
    visited = set()
    visited.add(tuple(map(tuple, initial_state.board)))

    while priority_queue:
        current_state = heapq.heappop(priority_queue)

        if current_state.is_goal():
            return current_state.path()

        for neighbor in current_state.neighbors():
            neighbor_board_tuple = tuple(map(tuple, neighbor.board))
            if neighbor_board_tuple not in visited:
                visited.add(neighbor_board_tuple)
                heapq.heappush(priority_queue, neighbor)

    return None  # No solution


# Example initial board configuration
initial_board = [
    [1, 2, 3],
    [4, 0, 6],
    [7, 5, 8]
]

solution_path = solve_puzzle(initial_board)
if solution_path:
    print("Solution found:")
    for step in solution_path:
        for row in step:
            print(row)
        print()
else:
    print("No solution exists.")
