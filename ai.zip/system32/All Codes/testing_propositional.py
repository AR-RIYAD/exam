from logic import *

P,Q,R,S = vars('P', 'Q', 'R', 'S')

