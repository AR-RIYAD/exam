import random

def objective_function(solution):
    # Replace this with your actual objective function
    # Example: Maximizing the sum of values in the solution
    return sum(solution)

def initialize_population(population_size, solution_size):
    # Generate a random population of solutions
    return [[random.randint(0, 1) for _ in range(solution_size)] for _ in range(population_size)]

def crossover(parent1, parent2):
    # Perform crossover (single-point crossover in this example)
    crossover_point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

def mutate(solution, mutation_rate):
    # Perform mutation (bit-flip mutation in this example)
    mutated_solution = [bit ^ (random.random() < mutation_rate) for bit in solution]
    return mutated_solution

def select_parents(population, num_parents):
    # Select parents based on tournament selection
    tournament_size = 2
    selected_parents = []
    for _ in range(num_parents):
        tournament = random.sample(population, tournament_size)
        selected_parents.append(max(tournament, key=objective_function))
    return selected_parents

def genetic_algorithm(population_size, solution_size, crossover_rate, mutation_rate, generations):
    # Initialize population
    population = initialize_population(population_size, solution_size)

    for generation in range(generations):
        # Evaluate fitness of each solution in the population
        fitness_values = [objective_function(solution) for solution in population]

        # Select parents for crossover
        num_parents = population_size // 2
        parents = select_parents(population, num_parents)

        # Create new generation through crossover and mutation
        new_generation = []
        while len(new_generation) < population_size:
            parent1, parent2 = random.sample(parents, 2)
            if random.random() < crossover_rate:
                child1, child2 = crossover(parent1, parent2)
            else:
                child1, child2 = parent1, parent2
            child1 = mutate(child1, mutation_rate)
            child2 = mutate(child2, mutation_rate)
            new_generation.extend([child1, child2])

        # Replace the old population with the new generation
        population = new_generation

    # Return the best solution found
    best_solution = max(population, key=objective_function)
    return best_solution, objective_function(best_solution)

# Example usage:
population_size = 50
solution_size = 10
crossover_rate = 0.8
mutation_rate = 0.01
generations = 100

best_solution, best_fitness = genetic_algorithm(population_size, solution_size, crossover_rate, mutation_rate, generations)

print("Best Solution:", best_solution)
print("Best Fitness:", best_fitness)
