import random

class MaxValueProblem:
    def __init__(self, values):
        self.values = values

    def initial_state(self):
        return random.choice(self.values)

    def heuristic(self, state):
        return state

    def neighbors(self, state):
        # Swap the current value with a random value in the list
        neighbors = list(self.values)
        neighbors.remove(state)
        return random.choice(neighbors)

def hill_climbing_search(problem, max_iterations=100):
    current_state = problem.initial_state()

    for _ in range(max_iterations):
        neighbors = problem.neighbors(current_state)
        if problem.heuristic(neighbors) <= problem.heuristic(current_state):
            break  # Local minimum or maximum reached

        current_state = neighbors

    return current_state

# Example usage
values = [1, 5, 3, 8, 2, 7]
problem = MaxValueProblem(values)

result = hill_climbing_search(problem)
print(f"Best solution found: {result}, Heuristic value: {problem.heuristic(result)}")
