def print_board(board):
    """Helper function to print the board."""
    for row in board:
        print(" ".join(row))
    print()


def is_safe(board, row, col):
    """Check if it's safe to place a queen at board[row][col]."""
    # Check the column
    for i in range(row):
        if board[i][col] == "Q":
            return False

    # Check the upper left diagonal
    i, j = row, col
    while i >= 0 and j >= 0:
        if board[i][j] == "Q":
            return False
        i -= 1
        j -= 1

    # Check the upper right diagonal
    i, j = row, col
    while i >= 0 and j < len(board):
        if board[i][j] == "Q":
            return False
        i -= 1
        j += 1

    return True


def solve_n_queens(board, row):
    """Recursive function to solve the N-Queens problem."""
    n = len(board)
    if row == n:  # Base case: all queens are placed
        print_board(board)
        return True

    # Try placing a queen in each column in the current row
    for col in range(n):
        if is_safe(board, row, col):
            board[row][col] = "Q"  # Place queen
            if solve_n_queens(board, row + 1):  # Recur to place the next queen
                return True
            board[row][col] = "."  # Backtrack if placing queen here doesn't lead to a solution

    return False


def solve_8_queens():
    """Initialize an 8x8 board and solve the 8-queens problem."""
    n = 8
    board = [["." for _ in range(n)] for _ in range(n)]
    if not solve_n_queens(board, 0):
        print("No solution exists.")


solve_8_queens()
