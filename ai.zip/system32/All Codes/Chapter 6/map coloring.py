
#map coloring
def is_valid(graph, node, color, assignment):
    for neighbor in graph[node]:
        if neighbor in assignment and assignment[neighbor] == color:
            return False
    return True

def map_coloring(graph, colors, assignment=None):
    if assignment is None:
        assignment = {}

    if len(assignment) == len(graph):
        return assignment  # All regions are colored

    node = next(node for node in graph if node not in assignment)

    for color in colors:
        if is_valid(graph, node, color, assignment):
            assignment[node] = color
            result = map_coloring(graph, colors, assignment)
            if result is not None:
                return result
            assignment.pop(node)

    return None  # No valid coloring found

# Example usage:

# Define the map graph (adjacency list)
map_graph = {
    'WA': ['NT', 'SA'],
    'NT': ['WA', 'SA', 'Q'],
    'SA': ['WA', 'NT', 'Q', 'NSW', 'V'],
    'Q': ['NT', 'SA', 'NSW'],
    'NSW': ['Q', 'SA', 'V'],
    'V': ['SA', 'NSW']
}

# Define available colors
color_options = ['Red', 'Green', 'Blue']

# Solve the map coloring problem
solution = map_coloring(map_graph, color_options)

# Display the solution
for region, color in solution.items():
    print(f'{region}: {color}')
