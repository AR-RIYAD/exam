# Import required libraries
from keras.models import Sequential
from keras.layers import Dense
import numpy as np

# Define input data (XOR truth table)
x = np.array([[0,0], [0,1], [1,0], [1,1]])  # Inputs
y = np.array([[0], [1], [1], [0]])           # Outputs

# Initialize the neural network model
model = Sequential()

# Add layers to the model
model.add(Dense(4, input_dim=2, activation='relu'))  # Hidden layer with 4 neurons
model.add(Dense(1, activation='sigmoid'))            # Output layer with 1 neuron

# Compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train the model
model.fit(x, y, epochs=1000, verbose=1)

# Evaluate the model
loss, accuracy = model.evaluate(x, y, verbose=0)
print(f"Model Accuracy: {accuracy * 100:.2f}%")

# Make predictions
predictions = model.predict(x)
print("Predictions:")
print(predictions.round())  # Rounding the predictions to see binary output
