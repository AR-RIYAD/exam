# Define parent relationship using a dictionary
parents = {
    "John": "Mary",  # John is Mary's parent
    "Mary": "Joe"    # Mary is Joe's parent
}

# Define the Parent predicate
def Parent(x, y):
    return parents.get(x) == y

# Define the Grandparent predicate
def Grandparent(x, z):
    # x is the grandparent of z if there exists a y such that Parent(x, y) and Parent(y, z)
    for y in parents:
        if Parent(x, y) and Parent(y, z):
            return True
    return False

# Check if John is the grandparent of Joe
print("Is John the grandparent of Joe?")
print(Grandparent("John", "Joe"))  # Expected: True
