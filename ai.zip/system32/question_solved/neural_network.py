import numpy as np

class NeuralNetwork:
    def __init__(self):
        # Set the input, hidden, and output sizes based on your network
        self.input_size = 2
        self.hidden_size = 2
        self.output_size = 2

        # Initialize weights with given values
        self.weights_input_hidden = np.array([[15.0, 25.0], [20.0, 30.0]])
        self.weights_hidden_output = np.array([[40.0, 50.0], [45.0, 55.0]])

        # Initialize biases with given values
        self.bias_hidden = np.array([[35.0, 60.0]])
        self.bias_output = np.array([[1.0, 1.0]])

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def feedforward(self, X):
        # Input to hidden layer
        self.hidden_activation = np.dot(X, self.weights_input_hidden) + self.bias_hidden
        self.hidden_output = self.sigmoid(self.hidden_activation)

        # Hidden to output layer
        self.output_activation = np.dot(self.hidden_output, self.weights_hidden_output) + self.bias_output
        self.predicted_output = self.sigmoid(self.output_activation)

        return self.predicted_output

    def backward(self, X, y, learning_rate):
        # Compute the output layer error
        output_error = y - self.predicted_output
        output_delta = output_error * self.sigmoid_derivative(self.predicted_output)

        # Compute the hidden layer error
        hidden_error = np.dot(output_delta, self.weights_hidden_output.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.hidden_output)

        # Update weights and biases
        self.weights_hidden_output += np.dot(self.hidden_output.T, output_delta) * learning_rate
        self.bias_output += np.sum(output_delta, axis=0, keepdims=True) * learning_rate
        self.weights_input_hidden += np.dot(X.T, hidden_delta) * learning_rate
        self.bias_hidden += np.sum(hidden_delta, axis=0, keepdims=True) * learning_rate

    def train(self, X, y, epochs, learning_rate):
        for epoch in range(epochs):
            output = self.feedforward(X)
            self.backward(X, y, learning_rate)
            if epoch % 4000 == 0:
                loss = np.mean(np.square(y - output))
                print(f"Epoch {epoch}, Loss: {loss}")

        # Print the estimated weights and biases after training
        print("\nEstimated weights (input to hidden):")
        print(self.weights_input_hidden)
        print("\nEstimated weights (hidden to output):")
        print(self.weights_hidden_output)
        print("\nEstimated hidden biases:")
        print(self.bias_hidden)
        print("\nEstimated output biases:")
        print(self.bias_output)

# Input and target output (Example input and output values)
X = np.array([[0.05, 0.10]])  # Replace with actual input values
y = np.array([[0.01, 0.99]])  # Replace with actual output values

# Create and train the neural network
nn = NeuralNetwork()
nn.train(X, y, epochs=10000, learning_rate=0.1)

# Test the trained model
output = nn.feedforward(X)
print("\nPredictions after training:")
print(output)
