import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn import tree

# Dataset from the image
data = {
    'Outlook': ['sunny', 'sunny', 'overcast', 'rainy', 'rainy', 'rainy', 'overcast', 'sunny', 'sunny', 'rainy',
                'sunny', 'overcast', 'overcast', 'rainy'],
    'Temperature': ['hot', 'hot', 'hot', 'mild', 'cool', 'cool', 'cool', 'mild', 'cool', 'mild',
                    'mild', 'mild', 'hot', 'mild'],
    'Humidity': ['high', 'high', 'high', 'high', 'normal', 'normal', 'normal', 'high', 'normal', 'normal',
                 'normal', 'high', 'normal', 'high'],
    'Windy': [False, True, False, False, False, True, True, False, False, False, True, True, False, True],
    'Play': ['no', 'no', 'yes', 'yes', 'yes', 'no', 'yes', 'no', 'yes', 'yes',
             'yes', 'yes', 'yes', 'no']
}

# Convert data to DataFrame
df = pd.DataFrame(data)

# Encoding categorical features
encoders = {}
for column in df.columns:
    encoders[column] = LabelEncoder()
    df[column] = encoders[column].fit_transform(df[column])

# Splitting features and target
X = df[['Outlook', 'Temperature', 'Humidity', 'Windy']]
y = df['Play']

# Training the Decision Tree model
clf = DecisionTreeClassifier(criterion='entropy')
clf = clf.fit(X, y)

# Visualizing the Decision Tree
feature_names = ['Outlook', 'Temperature', 'Humidity', 'Windy']
class_names = ['No', 'Yes']
tree.plot_tree(clf, feature_names=feature_names, class_names=class_names, filled=True)

# Test the model with a new case
# Example new case: Outlook=sunny, Temperature=hot, Humidity=high, Windy=False
new_case = pd.DataFrame({
    'Outlook': [encoders['Outlook'].transform(['rainy'])[0]],
    'Temperature': [encoders['Temperature'].transform(['cool'])[0]],
    'Humidity': [encoders['Humidity'].transform(['normal'])[0]],
    'Windy': [encoders['Windy'].transform([True])[0]]
})

prediction = clf.predict(new_case)
print("Prediction for new case:", 'Play' if prediction[0] == 1 else 'No Play')
