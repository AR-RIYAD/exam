import random
import copy

# Define the goal state
goal_state = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, None]
]


# Check if the puzzle is in the goal state
def is_goal(state):
    return state == goal_state


# Find the blank (None) position in the puzzle
def find_blank(state):
    for i in range(len(state)):
        for j in range(len(state[i])):
            if state[i][j] is None:
                return i, j
    return None


# Calculate the heuristic (number of misplaced tiles)
def calculate_heuristic(state):
    misplaced = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] is not None and state[i][j] != goal_state[i][j]:
                misplaced += 1
    return misplaced


# Generate possible moves for the blank tile (None)
def get_neighbors(state):
    neighbors = []
    blank_x, blank_y = find_blank(state)

    # Define possible moves (up, down, left, right)
    moves = [
        (blank_x - 1, blank_y),  # Up
        (blank_x + 1, blank_y),  # Down
        (blank_x, blank_y - 1),  # Left
        (blank_x, blank_y + 1)  # Right
    ]

    for new_x, new_y in moves:
        if 0 <= new_x < 3 and 0 <= new_y < 3:
            # Create a new state by swapping the blank with the adjacent tile
            new_state = copy.deepcopy(state)
            new_state[blank_x][blank_y], new_state[new_x][new_y] = new_state[new_x][new_y], new_state[blank_x][blank_y]
            neighbors.append(new_state)

    return neighbors


# Hill Climbing algorithm
def hill_climbing(start_state):
    current_state = start_state
    current_heuristic = calculate_heuristic(current_state)
    steps = 0

    while not is_goal(current_state):
        neighbors = get_neighbors(current_state)
        next_state = None
        next_heuristic = current_heuristic

        # Find the neighbor with the best (lowest) heuristic
        for neighbor in neighbors:
            neighbor_heuristic = calculate_heuristic(neighbor)
            if neighbor_heuristic < next_heuristic:
                next_state = neighbor
                next_heuristic = neighbor_heuristic

        # If no improvement, stop
        if next_state is None or next_heuristic >= current_heuristic:
            print("Reached local maximum or goal!")
            break

        # Move to the neighbor with the lowest heuristic
        current_state = next_state
        current_heuristic = next_heuristic
        steps += 1
        print(f"Step {steps} - Heuristic: {current_heuristic}")
        print_state(current_state)

    return current_state


# Print the puzzle state
def print_state(state):
    for row in state:
        print(" ".join(str(x) if x is not None else " " for x in row))
    print()


# Example initial state (replace with any initial configuration)
initial_state = [
    [1, 2, 3],
    [4, None, 5],
    [7, 8, 6]
]

print("Initial State:")
print_state(initial_state)

# Solve the puzzle
result = hill_climbing(initial_state)

print("Final State:")
print_state(result)
